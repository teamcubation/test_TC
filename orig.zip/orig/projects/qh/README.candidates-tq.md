Flujo assessment:

frontend -> login
authe (pep) -> validar credenciales
authe-> genera y entrega el token al frontend
frontend -> assessment
person -> crear person
candidate -> crear candidate
assessments -> crear assessment
assessments -> crear link assessment
notification -> enviar link assessment

---

Flujo candidato:

email candidato -> clic link únic assessment
authe -> validar token assessment
IA (python)-> preguntas y creacion de assessment
assessment -> validar assessement
assessment -> marcar assessment como realizado
