package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"time"

	gorm "github.com/devpablocristo/monorepo/pkg/databases/sql/gorm"

	assessmentmodels "github.com/devpablocristo/monorepo/projects/qh/internal/assessment/repository/models"
	candidatemodels "github.com/devpablocristo/monorepo/projects/qh/internal/candidate/repository/models"
	groupmodels "github.com/devpablocristo/monorepo/projects/qh/internal/group/repository/models"
	personmodels "github.com/devpablocristo/monorepo/projects/qh/internal/person/repository/models"
	wire "github.com/devpablocristo/monorepo/projects/qh/wire"
)

func RunWebServer(ctx context.Context, deps *wire.Dependencies) error {
	if deps == nil {
		return errors.New("dependencies cannot be nil")
	}

	log.Println("Initializing routes...")

	// Manejo de errores en middlewares
	defer func() {
		if r := recover(); r != nil {
			err, ok := r.(error)
			if ok {
				log.Printf("Error while initializing middlewares: %v\n", err)
			} else {
				log.Printf("Unknown panic occurred: %v\n", r)
			}
		}
	}()

	// Configurar middlewares globales primero
	if len(deps.Middlewares.Global) > 0 {
		deps.GinServer.GetRouter().Use(deps.Middlewares.Global...)
	}

	// Registrar rutas
	registerRoutes(deps)

	log.Println("Starting Gin server...")
	return deps.GinServer.RunServer(ctx)
}

func registerRoutes(deps *wire.Dependencies) {
	deps.EventHandler.Routes()
	deps.GroupHandler.Routes()
	deps.PersonHandler.Routes()
	deps.AssessmentHandler.Routes()
	deps.CandidateHandler.Routes()
	deps.UserHandler.Routes()
	deps.AutheHandler.Routes()
	deps.NotificationHandler.Routes()
}

func RunGormMigrations(ctx context.Context, repo gorm.Repository) error {
	log.Println("Starting database migrations...")

	// Verificar la conexión antes de proceder
	sqlDB, err := repo.Client().DB()
	if err != nil {
		return fmt.Errorf("failed to get database connection: %w", err)
	}
	if err := sqlDB.PingContext(ctx); err != nil {
		return fmt.Errorf("database connection failed: %w", err)
	}

	// Lista de modelos a migrar
	modelsToMigrate := []any{
		&groupmodels.Group{},
		&groupmodels.GroupMember{},
		&assessmentmodels.Assessment{},
		&assessmentmodels.Problem{},
		&assessmentmodels.SkillConfig{},
		&assessmentmodels.UnitTest{},
		&candidatemodels.Candidate{},
		&personmodels.Person{},
		&assessmentmodels.Link{},
		// Otros modelos...
	}

	// Medir el tiempo de ejecución
	start := time.Now()
	if err := repo.AutoMigrate(modelsToMigrate...); err != nil {
		return fmt.Errorf("failed to migrate database models: %w", err)
	}
	duration := time.Since(start)

	log.Printf("Database migrations completed successfully in %s.", duration)
	return nil
}
