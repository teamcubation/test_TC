package main

import (
	"context"
	"log"
	"os"
	"os/signal"
	"syscall"

	"github.com/devpablocristo/monorepo/projects/qh/wire"
)

func main() {
	// Create a context with cancellation to handle graceful shutdown
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// Capture system signals for clean termination
	go func() {
		sigChan := make(chan os.Signal, 1)
		signal.Notify(sigChan, os.Interrupt, syscall.SIGTERM)

		<-sigChan // Wait for a signal
		log.Println("Received termination signal. Shutting down the application...")
		cancel()
	}()

	// Initialize dependencies using Wire
	deps, err := wire.Initialize()
	if err != nil {
		log.Fatalf("Error initializing dependencies: %s", err)
	}

	if err := RunGormMigrations(ctx, deps.GormRepository); err != nil {
		log.Fatalf("Failed to run migrations: %v", err)
	}

	if err := RunWebServer(ctx, deps); err != nil {
		log.Fatalf("Error starting the application: %s", err)
	}

	log.Println("Application terminated successfully.")
}

// INFO: auth1
// package main

// import (
// 	"context"
// 	"fmt"
// 	"log"

// 	"github.com/aws/aws-sdk-go-v2/service/s3"

// 	sdkaws "github.com/devpablocristo/sdk/pkg/aws/localstack"
// 	sdkcnfldr "github.com/devpablocristo/sdk/pkg/config/config-loader"

// 	authconn "github.com/devpablocristo/sdk/sg/auth/internal/adapters/connectors"
// 	authgtw "github.com/devpablocristo/sdk/sg/auth/internal/adapters/gateways"
// 	auth "github.com/devpablocristo/sdk/sg/auth/internal/core"
// )

// func init() {
// 	if err := sdkcnfldr.LoadConfig("config/.env", "config/.env.local"); err != nil {
// 		log.Fatalf("Viper Service error: %v", err)
// 	}
// }

// func awsInit() error {
// 	// AWS
// 	stack, err := sdkaws.Bootstrap()
// 	if err != nil {
// 		return err
// 	}

// 	// Usar la configuración de AWS
// 	awsCfg := stack.GetConfig()

// 	// Por ejemplo, crear un cliente para S3
// 	//s3Client
// 	_ = s3.NewFromConfig(awsCfg)

// 	fmt.Println("AWS stack initialized successfully with LocalStack")

// 	return nil
// }

// func main() {
// 	if err := awsInit(); err != nil {
// 		log.Fatalf("Failed to bootstrap AWS stack: %v", err)
// 	}

// 	ctx, cancel := context.WithCancel(context.Background()) // Crear el contexto
// 	defer cancel()                                          // Asegurarse de cancelar el contexto al final

// 	jwtService, err := authconn.NewJwtService()
// 	if err != nil {
// 		log.Fatalf("JWT Service error: %v", err)
// 	}

// 	httpClient, err := authconn.NewHttpClient()
// 	if err != nil {
// 		log.Fatalf("Http Client error: %v", err)
// 	}

// 	sessionManager, err := authconn.NewGorillaSessionManager()
// 	if err != nil {
// 		log.Fatalf("Http Client error: %v", err)
// 	}

// 	repository, err := authconn.NewPostgreSQL()
// 	if err != nil {
// 		log.Fatalf("PostgreSQL error: %v", err)
// 	}

// 	cache, err := authconn.NewRedis()
// 	if err != nil {
// 		log.Fatalf("Redis error: %v", err)
// 	}

// 	authUsecases := auth.NewUseCases(jwtService, repository, httpClient, sessionManager, cache)

// 	authHandler, err := authgtw.NewGinHandler(authUsecases)
// 	if err != nil {
// 		log.Fatalf("Auth Handler error: %v", err)
// 	}

// 	authGrpcServer, err := authgtw.NewGrpcServer(authUsecases)
// 	if err != nil {
// 		log.Fatalf("Auth gRPC Server error: %v", err)
// 	}

// 	go func() {
// 		if err := authGrpcServer.Start(ctx); err != nil {
// 			log.Fatalf("gRPC Server error at start: %v", err)
// 		}
// 	}()

// 	err = authHandler.Start(ctx)
// 	if err != nil {
// 		log.Fatalf("Gin Server error at start: %v", err)
// 	}

// }

// INFOR: auth2
// package main

// import (
// 	"context"
// 	"fmt"
// 	"log"

// 	"github.com/aws/aws-sdk-go-v2/service/s3"

// 	sdkaws "github.com/teamcubation/sg-backend/pkg/aws/localstack"
// 	sdkcnfldr "github.com/teamcubation/sg-backend/pkg/config/config-loader"

// 	authconn "github.com/teamcubation/sg-backend/services/auth-old/internal/adapters/connectors"
// 	authgtw "github.com/teamcubation/sg-backend/services/auth-old/internal/adapters/gateways"
// 	auth "github.com/teamcubation/sg-backend/services/auth-old/internal/core"
// )

// func init() {
// 	if err := sdkcnfldr.LoadConfig("config/.env", "config/.env.local"); err != nil {
// 		log.Fatalf("Viper Service error: %v", err)
// 	}
// }

// func awsInit() error {
// 	// AWS
// 	stack, err := sdkaws.Bootstrap()
// 	if err != nil {
// 		return err
// 	}

// 	// Usar la configuración de AWS
// 	awsCfg := stack.GetConfig()

// 	// Por ejemplo, crear un cliente para S3
// 	//s3Client
// 	_ = s3.NewFromConfig(awsCfg)

// 	fmt.Println("AWS stack initialized successfully with LocalStack")

// 	return nil
// }

// func main() {
// 	if err := awsInit(); err != nil {
// 		log.Fatalf("Failed to bootstrap AWS stack: %v", err)
// 	}

// 	ctx, cancel := context.WithCancel(context.Background()) // Crear el contexto
// 	defer cancel()                                          // Asegurarse de cancelar el contexto al final

// 	jwtService, err := authconn.NewJwtService()
// 	if err != nil {
// 		log.Fatalf("JWT Service error: %v", err)
// 	}

// 	httpClient, err := authconn.NewHttpClient()
// 	if err != nil {
// 		log.Fatalf("Http Client error: %v", err)
// 	}

// 	sessionManager, err := authconn.NewGorillaSessionManager()
// 	if err != nil {
// 		log.Fatalf("Http Client error: %v", err)
// 	}

// 	repository, err := authconn.NewPostgreSQL()
// 	if err != nil {
// 		log.Fatalf("PostgreSQL error: %v", err)
// 	}

// 	cache, err := authconn.NewRedis()
// 	if err != nil {
// 		log.Fatalf("Redis error: %v", err)
// 	}

// 	authUsecases := auth.NewUseCases(jwtService, repository, httpClient, sessionManager, cache)

// 	authHandler, err := authgtw.NewGinHandler(authUsecases)
// 	if err != nil {
// 		log.Fatalf("Auth Handler error: %v", err)
// 	}

// 	authGrpcServer, err := authgtw.NewGrpcServer(authUsecases)
// 	if err != nil {
// 		log.Fatalf("Auth gRPC Server error: %v", err)
// 	}

// 	go func() {
// 		if err := authGrpcServer.Start(ctx); err != nil {
// 			log.Fatalf("gRPC Server error at start: %v", err)
// 		}
// 	}()

// 	err = authHandler.Start(ctx)
// 	if err != nil {
// 		log.Fatalf("Gin Server error at start: %v", err)
// 	}

// }

// INFO: authe
// package main

// import (
// 	"log"
// 	"sync"

// 	sdkviper "github.com/devpablocristo/golang/sdk/pkg/configurators/viper"
// 	sdkgmgs "github.com/devpablocristo/golang/sdk/pkg/microservices/go-micro/v4/grpc-service"
// 	sdkgmws "github.com/devpablocristo/golang/sdk/pkg/microservices/go-micro/v4/web-server"

// 	authconn "github.com/devpablocristo/golang/sdk/qh/authe/internal/adapters/connectors"
// 	authgtw "github.com/devpablocristo/golang/sdk/qh/authe/internal/adapters/gateways"
// 	authe "github.com/devpablocristo/golang/sdk/qh/authe/internal/core"
// )

// func init() {
// 	if err := sdkviper.LoadConfig(); err != nil {
// 		log.Fatalf("Viper Service error: %v", err)
// 	}
// }

// func main() {
// 	grpcClient, err := authconn.NewGrpcClient()
// 	if err != nil {
// 		log.Fatalf("Go Micro gRPC Client error: %v", err)
// 	}

// 	redisService, err := authconn.NewRedisService()
// 	if err != nil {
// 		log.Fatalf("Redis error: %v", err)
// 	}

// 	jwtService, err := authconn.NewJwtService()
// 	if err != nil {
// 		log.Fatalf("JWT Service error: %v", err)
// 	}

// 	authUsecases := authe.NewUseCases(grpcClient, redisService, jwtService)

// 	grpcServer, err := authgtw.NewGrpcServer(authUsecases)
// 	if err != nil {
// 		log.Fatalf("Go Micro gRPC Server error: %v", err)
// 	}

// 	authHandler, err := authgtw.NewGinHandler(authUsecases)
// 	if err != nil {
// 		log.Fatalf("Error: %v", err)
// 	}

// 	grpcService, err := sdkgmgs.Bootstrap(grpcServer.GetServer(), grpcClient.GetClient())
// 	if err != nil {
// 		log.Fatalf("Go Micro service Boostrap error: %v", err)
// 	}

// 	webServer, err := sdkgmws.Bootstrap(authHandler.GetRouter())
// 	if err != nil {
// 		log.Fatalf("GoMicro Service error: %v", err)
// 	}

// 	var wg sync.WaitGroup
// 	wg.Add(2)

// 	go func() {
// 		defer wg.Done()
// 		if err := webServer.Run(); err != nil {
// 			log.Fatalf("Error starting Web Server: %v", err)
// 		}
// 	}()

// 	go func() {
// 		defer wg.Done()
// 		if err := grpcService.Run(); err != nil {
// 			log.Fatalf("Error starting gRPC Service: %v", err)
// 		}
// 	}()

// 	wg.Wait()
// }

//  INFO: rating
// package main

// import (
// 	"log"
// 	"sync"

// 	sdkviper "github.com/devpablocristo/golang/sdk/pkg/configurators/viper"
// 	sdkgmgs "github.com/devpablocristo/golang/sdk/pkg/microservices/go-micro/v4/grpc-service"
// 	sdkgmws "github.com/devpablocristo/golang/sdk/pkg/microservices/go-micro/v4/web-server"

// 	ratconn "github.com/devpablocristo/golang/sdk/qh/rating/internal/adapters/connectors"
// 	ratgtw "github.com/devpablocristo/golang/sdk/qh/rating/internal/adapters/gateways"
// 	rating "github.com/devpablocristo/golang/sdk/qh/rating/internal/core"
// )

// func init() {
// 	if err := sdkviper.LoadConfig(); err != nil {
// 		log.Fatalf("Viper Service error: %v", err)
// 	}
// }

// func main() {
// 	ratGrpcClient, err := ratconn.NewGrpcClient()
// 	if err != nil {
// 		log.Fatalf("Go Micro gRPC Client error: %v", err)
// 	}

// 	ratUsecases := rating.NewUseCases(ratGrpcClient)

// 	ratGrpcServer, err := ratgtw.NewGrpcServer(ratUsecases)
// 	if err != nil {
// 		log.Fatalf("Go Micro gRPC Server error: %v", err)
// 	}

// 	ratHandler, err := ratgtw.NewGinHandler(ratUsecases)
// 	if err != nil {
// 		log.Fatalf("Error: %v", err)
// 	}

// 	ratGrpcService, err := sdkgmgs.Bootstrap(ratGrpcServer.GetServer(), ratGrpcClient.GetClient())
// 	if err != nil {
// 		log.Fatalf("Go Micro service Boostrap error: %v", err)
// 	}

// 	ratWebServer, err := sdkgmws.Bootstrap(ratHandler.GetRouter())
// 	if err != nil {
// 		log.Fatalf("GoMicro Service error: %v", err)
// 	}

// 	var wg sync.WaitGroup
// 	wg.Add(2)

// 	go func() {
// 		defer wg.Done()
// 		if err := ratWebServer.Run(); err != nil {
// 			log.Fatalf("Error starting Web Server: %v", err)
// 		}
// 	}()

// 	go func() {
// 		defer wg.Done()
// 		if err := ratGrpcService.Run(); err != nil {
// 			log.Fatalf("Error starting gRPC Service: %v", err)
// 		}
// 	}()

// 	wg.Wait()
// }

// INFO: monitoriong
// package main

// import (
// 	"log"

// 	sdkviper "github.com/devpablocristo/golang/sdk/pkg/configurators/viper"
// 	sdkmysql "github.com/devpablocristo/golang/sdk/pkg/databases/sql/mysql/go-sql-driver"
// 	sdkmysqlports "github.com/devpablocristo/golang/sdk/pkg/databases/sql/mysql/go-sql-driver/ports"
// 	sdkgin "github.com/devpablocristo/golang/sdk/pkg/rest/gin"
// 	portsgin "github.com/devpablocristo/golang/sdk/pkg/rest/gin/ports"
// 	gtwmon "github.com/devpablocristo/golang/sdk/services/monitoring/gateways/monitoring"
// 	coremon "github.com/devpablocristo/golang/sdk/services/monitoring/internal/monitoring"
// )

// func init() {
// 	// Para correr en local
// 	// if err := sdkviper.LoadConfig("../../../"); err != nil {
// 	if err := sdkviper.LoadConfig(); err != nil {
// 		log.Fatalf("Viper Service error: %v", err)
// 	}
// }

// func main() {
// 	ginServer, mysqlRepository := lauchBootstraps()

// 	monRepository := coremon.NewMySqlRepository(mysqlRepository)
// 	monUsecases := coremon.NewUseCases(monRepository)
// 	monHandler := gtwmon.NewGinHandler(monUsecases, ginServer)

// 	if err := monHandler.Start("v1"); err != nil {
// 		log.Fatalf("Failed to start server: %v", err)
// 	}

// }

// func lauchBootstraps() (portsgin.Server, sdkmysqlports.Repository) {
// 	mysqlRepository, err := sdkmysql.Bootstrap()
// 	if err != nil {
// 		log.Fatalf("MySQL Service error: %v", err)
// 	}

// 	ginServer, err := sdkgin.Bootstrap()
// 	if err != nil {
// 		log.Fatalf("Gin Service error: %v", err)
// 	}

// 	return ginServer, mysqlRepository
// }

// INFO: users
// package main

// import (
// 	"context"
// 	"log"

// 	sdkcnfldr "github.com/devpablocristo/sdk/pkg/config/config-loader"

// 	userconn "github.com/devpablocristo/sdk/sg/users/internal/adapters/connectors"
// 	usergtw "github.com/devpablocristo/sdk/sg/users/internal/adapters/gateways"
// 	personconn "github.com/devpablocristo/sdk/sg/users/internal/person/adapters/connectors"

// 	user "github.com/devpablocristo/sdk/sg/users/internal/core"
// 	person "github.com/devpablocristo/sdk/sg/users/internal/person/core"
// )

// func init() {
// 	if err := sdkcnfldr.LoadConfig("config/.env", "config/.env.local"); err != nil {
// 		log.Fatalf("Viper Service error: %v", err)
// 	}
// }

// // NOTE: no pude implementar wire todavia, dan errores que no entiendo, mirar mas adelante
// func main() {

// 	ctx, cancel := context.WithCancel(context.Background()) // Crear el contexto
// 	defer cancel()

// 	personRepo, err := personconn.NewPostgreSQL()
// 	if err != nil {
// 		log.Fatalf("Failed to initialize application: %v", err)
// 	}
// 	personUseCases := person.NewUseCases(personRepo)

// 	userRepo, err := userconn.NewPostgreSQL()
// 	if err != nil {
// 		log.Fatalf("Failed to initialize application: %v", err)
// 	}

// 	grpcClient, err := userconn.NewGrpcClient()
// 	if err != nil {
// 		log.Fatalf("Error al crear el cliente gRPC: %v", err)
// 	}
// 	defer grpcClient.Close()

// 	jwtService, err := userconn.NewJwtService()
// 	if err != nil {
// 		log.Fatalf("JWT Service error: %v", err)
// 	}

// 	cache, err := userconn.NewRedis()
// 	if err != nil {
// 		log.Fatalf("Redis error: %v", err)
// 	}

// 	messageQueu, err := userconn.NewSQS()
// 	if err != nil {
// 		log.Fatalf("SQS error: %v", err)
// 	}

// 	usersUseCases := user.NewUseCases(userRepo, personUseCases, grpcClient, jwtService, cache, messageQueu)

// 	if err := usersUseCases.Foo(); err != nil {
// 		log.Fatalf(" %v", err)
// 	}

// 	userHandler, err := usergtw.NewGinHandler(usersUseCases)
// 	if err != nil {
// 		log.Fatalf("Failed to initialize application: %v", err)
// 	}

// 	// Iniciar el servidor de Gin
// 	err = userHandler.Start(ctx)
// 	if err != nil {
// 		log.Fatalf("Gin Server error at start: %v", err)
// 	}
// }

// INFOR: users 2
// package main

// import (
// 	"context"
// 	"log"

// 	sdkcnfldr "github.com/teamcubation/sg-backend/pkg/config/config-loader"

// 	userconn "github.com/teamcubation/sg-backend/services/users-old/internal/adapters/connectors"
// 	usergtw "github.com/teamcubation/sg-backend/services/users-old/internal/adapters/gateways"
// 	personconn "github.com/teamcubation/sg-backend/services/users-old/internal/person/adapters/connectors"

// 	user "github.com/teamcubation/sg-backend/services/users-old/internal/core"
// 	person "github.com/teamcubation/sg-backend/services/users-old/internal/person/core"
// )

// func init() {
// 	if err := sdkcnfldr.LoadConfig("config/.env", "config/.env.local"); err != nil {
// 		log.Fatalf("Viper Service error: %v", err)
// 	}
// }

// // NOTE: no pude implementar wire todavia, dan errores que no entiendo, mirar mas adelante
// func main() {

// 	ctx, cancel := context.WithCancel(context.Background()) // Crear el contexto
// 	defer cancel()

// 	personRepo, err := personconn.NewPostgreSQL()
// 	if err != nil {
// 		log.Fatalf("Failed to initialize application: %v", err)
// 	}
// 	personUseCases := person.NewUseCases(personRepo)

// 	userRepo, err := userconn.NewPostgreSQL()
// 	if err != nil {
// 		log.Fatalf("Failed to initialize application: %v", err)
// 	}

// 	grpcClient, err := userconn.NewGrpcClient()
// 	if err != nil {
// 		log.Fatalf("Error al crear el cliente gRPC: %v", err)
// 	}
// 	defer grpcClient.Close()

// 	jwtService, err := userconn.NewJwtService()
// 	if err != nil {
// 		log.Fatalf("JWT Service error: %v", err)
// 	}

// 	cache, err := userconn.NewRedis()
// 	if err != nil {
// 		log.Fatalf("Redis error: %v", err)
// 	}

// 	messageQueu, err := userconn.NewSQS()
// 	if err != nil {
// 		log.Fatalf("SQS error: %v", err)
// 	}

// 	usersUseCases := user.NewUseCases(userRepo, personUseCases, grpcClient, jwtService, cache, messageQueu)

// 	if err := usersUseCases.Foo(); err != nil {
// 		log.Fatalf(" %v", err)
// 	}

// 	userHandler, err := usergtw.NewGinHandler(usersUseCases)
// 	if err != nil {
// 		log.Fatalf("Failed to initialize application: %v", err)
// 	}

// 	// Iniciar el servidor de Gin
// 	err = userHandler.Start(ctx)
// 	if err != nil {
// 		log.Fatalf("Gin Server error at start: %v", err)
// 	}
// }

// INFO: notification
// package main

// import (
// 	"context"
// 	"fmt"
// 	"log"

// 	"github.com/spf13/viper"

// 	sdkcnfldr "github.com/teamcubation/sg-backend/pkg/config/config-loader"

// 	mailconn "github.com/teamcubation/sg-backend/services/notification-old/internal/adapters/connectors"
// 	mailgtw "github.com/teamcubation/sg-backend/services/notification-old/internal/adapters/gateways"
// 	notification "github.com/teamcubation/sg-backend/services/notification-old/internal/core"
// )

// func init() {
// 	if err := sdkcnfldr.LoadConfig("config/.env", "config/.env.local"); err != nil {
// 		log.Fatalf("Viper Service error: %v", err)
// 	}

// 	fmt.Println("JWT Var: ", viper.GetString("AFIP_CLIENT_SECRET"))
// }

// func main() {

// 	ctx, cancel := context.WithCancel(context.Background()) // Crear el contexto
// 	defer cancel()

// 	jwtService, err := mailconn.NewJwtService()
// 	if err != nil {
// 		log.Fatalf("JWT Service error: %v", err)
// 	}

// 	smtpService, err := mailconn.NewSmtpService()
// 	if err != nil {
// 		log.Fatalf("Failed to initialize application: %v", err)
// 	}

// 	cache, err := mailconn.NewRedis()
// 	if err != nil {
// 		log.Fatal("Redis error: %v", err)
// 	}

// 	mailingUseCases := notification.NewUseCases(jwtService, smtpService, cache)

// 	userHandler, err := mailgtw.NewGinHandler(mailingUseCases)
// 	if err != nil {
// 		log.Fatalf("Failed to initialize handler: %v", err)
// 	}

// 	//fmt.Printf("Verification email sent to %s\n", email)

// 	err = userHandler.Start(ctx)
// 	if err != nil {
// 		log.Fatalf("Gin Server error at start: %v", err)
// 	}

// }

// INFO: Address
// package main

// import (
// 	"context"
// 	"log"

// 	sdkcnfldr "github.com/devpablocristo/sdk/pkg/config/config-loader"

// 	addrconn "github.com/devpablocristo/sdk/sg/address/internal/adapters/connectors"
// 	addrgtw "github.com/devpablocristo/sdk/sg/address/internal/adapters/gateways"
// 	addr "github.com/devpablocristo/sdk/sg/address/internal/core"
// )

// func init() {
// 	if err := sdkcnfldr.LoadConfig("config/.env", "config/.env.local"); err != nil {
// 		log.Fatalf("Viper Service error: %v", err)
// 	}
// }

// func main() {
// 	ctx, cancel := context.WithCancel(context.Background())
// 	defer cancel()

// 	httpClient, err := addrconn.NewHttpClient()
// 	if err != nil {
// 		log.Fatalf("Http Client error: %v", err)
// 	}

// 	repository, err := addrconn.NewPostgreSQL()
// 	if err != nil {
// 		log.Fatalf("PostgreSQL error: %v", err)
// 	}

// 	addrUsecases := addr.NewUseCases(repository, httpClient)

// 	addrHandler, err := addrgtw.NewGinHandler(addrUsecases)
// 	if err != nil {
// 		log.Fatalf("addr Handler error: %v", err)
// 	}

// 	err = addrHandler.Start(ctx)
// 	if err != nil {
// 		log.Fatalf("Gin Server error at start: %v", err)
// 	}

// }

// INFO: go-micro
// package main

// import (
// 	"log"

// 	gtwuser "github.com/devpablocristo/golang/sdk/services/user/gateways/user"

// 	// FIXME: Usar gRPC, no se puede importar desde internal
// 	coreuser "github.com/devpablocristo/golang/sdk/services/user/internal/user"

// 	sdkviper "github.com/devpablocristo/golang/sdk/pkg/configurators/viper"
// 	sdkmapdb "github.com/devpablocristo/golang/sdk/pkg/databases/in-memory/mapdb"
// 	portsmdb "github.com/devpablocristo/golang/sdk/pkg/databases/in-memory/mapdb/ports"
// 	sdkgomicro "github.com/devpablocristo/golang/sdk/pkg/microservices/go-micro/v4"
// 	portsgm "github.com/devpablocristo/golang/sdk/pkg/microservices/go-micro/v4/ports"
// 	sdkgin "github.com/devpablocristo/golang/sdk/pkg/rest/gin"
// 	portsgin "github.com/devpablocristo/golang/sdk/pkg/rest/gin/ports"
// )

// func init() {
// 	if err := sdkviper.LoadConfig(); err != nil {
// 		log.Fatalf("Viper Service error: %v", err)
// 	}
// }

// func main() {

// 	gomicroService, ginServer, mapdbService := setupServices()

// 	userRepository := coreuser.NewMapDbRepository(mapdbService)
// 	userUsecases := coreuser.NewUseCases(userRepository)
// 	userHandler := gtwuser.NewGinHandler(userUsecases, ginServer)
// 	userHandler.Routes("secret", "v1")

// 	go func() {
// 		if err := gomicroService.StartRcpService(); err != nil {
// 			log.Fatalf("Error starting GoMicro RPC Service: %v", err)
// 		}
// 	}()

// 	gomicroService.GetWebService().Handle("/", ginServer.GetRouter())

// 	if err := gomicroService.StartWebService(); err != nil {
// 		log.Fatalf("Error starting GoMicro Web Service: %v", err)
// 	}
// }

// func setupServices() (portsgm.Service, portsgin.Server, portsmdb.Repository) {
// 	gomicroService, err := sdkgomicro.Bootstrap()
// 	if err != nil {
// 		log.Fatalf("GoMicro Service error: %v", err)
// 	}

// 	//NOTE: gin NO se lanza,
// 	//NOTE: go-micro webservice si,
// 	//NOTE: de esta forma gin maneje las solicitudes
// 	//NOTE: y go-micro el resto
// 	ginServer, err := sdkgin.Bootstrap()
// 	if err != nil {
// 		log.Fatalf("Gin Service error: %v", err)
// 	}

// 	mapdbService, err := sdkmapdb.Boostrap()
// 	if err != nil {
// 		log.Fatalf("MapDB Service error: %v", err)
// 	}

// 	return gomicroService, ginServer, mapdbService

// }

// INFO: notification/notifications
// package main

// import (
// 	"context"
// 	"fmt"
// 	"log"

// 	"github.com/spf13/viper"

// 	sdkcnfldr "github.com/devpablocristo/sdk/pkg/config/config-loader"

// 	mailconn "github.com/devpablocristo/sdk/sg/notification/internal/adapters/connectors"
// 	mailgtw "github.com/devpablocristo/sdk/sg/notification/internal/adapters/gateways"
// 	notification "github.com/devpablocristo/sdk/sg/notification/internal/core"
// )

// func init() {
// 	if err := sdkcnfldr.LoadConfig("config/.env", "config/.env.local"); err != nil {
// 		log.Fatalf("Viper Service error: %v", err)
// 	}

// 	fmt.Println("JWT Var: ", viper.GetString("AFIP_CLIENT_SECRET"))
// }

// func main() {

// 	ctx, cancel := context.WithCancel(context.Background()) // Crear el contexto
// 	defer cancel()

// 	jwtService, err := mailconn.NewJwtService()
// 	if err != nil {
// 		log.Fatalf("JWT Service error: %v", err)
// 	}

// 	smtpService, err := mailconn.NewSmtpService()
// 	if err != nil {
// 		log.Fatalf("Failed to initialize application: %v", err)
// 	}

// 	cache, err := mailconn.NewRedis()
// 	if err != nil {
// 		log.Fatal("Redis error: %v", err)
// 	}

// 	mailingUseCases := notification.NewUseCases(jwtService, smtpService, cache)

// 	userHandler, err := mailgtw.NewGinHandler(mailingUseCases)
// 	if err != nil {
// 		log.Fatalf("Failed to initialize handler: %v", err)
// 	}

// 	//fmt.Printf("Verification email sent to %s\n", email)

// 	err = userHandler.Start(ctx)
// 	if err != nil {
// 		log.Fatalf("Gin Server error at start: %v", err)
// 	}

// }

// INFO: items
// package main

// import (
// 	"log"

// 	"github.com/gin-gonic/gin"

// 	handler "api/cmd/rest/handlers"
// 	core "api/internal/core"
// 	item "api/internal/core/item"
// 	mongodbsetup "api/internal/platform/mongodb"
// 	mysqlsetup "api/internal/platform/mysql"
// )

// func main() {
// 	// Configurar MySQL
// 	mysqlClient, err := mysqlsetup.NewMySQLSetup()
// 	if err != nil {
// 		log.Fatalf("não foi possível configurar o MySQL: %v", err)
// 	}
// 	defer mysqlClient.Close()

// 	mongoDBClient, err := mongodbsetup.NewMongoDBSetup()
// 	if err != nil {
// 		log.Fatalf("não foi possível configurar o MongoDB: %v", err)
// 	}
// 	defer mongoDBClient.Close()

// 	// Inicializar repositórios
// 	inMemoryRepo := item.NewInMemoryRepository()
// 	mysqlRepo := item.NewMySqlRepository(mysqlClient.DB())
// 	mongoDbRepo := item.NewMongoDbRepository(mongoDBClient.DB())

// 	_ = inMemoryRepo

// 	// Inicializar caso de uso com ambos repositórios
// 	usecase := core.NewItemUsecase(mysqlRepo, mongoDbRepo)

// 	// Inicializar handlers
// 	handler := handler.NewHandler(usecase)

// 	// Configurar roteador
// 	router := gin.Default()
// 	router.POST("/items", handler.SaveItem)
// 	router.GET("/items", handler.ListItems)

// 	// Iniciar servidor
// 	log.Println("Servidor iniciado em http://localhost:8080")
// 	if err := router.Run(":8080"); err != nil {
// 		log.Fatal(err)
// 	}
// }

// INDO: items 2
// package main

// import (
// 	"context"
// 	"flag"
// 	"log"
// 	"net/http"
// 	"os"
// 	"os/signal"
// 	"time"

// 	"github.com/gorilla/mux"
// 	"github.com/osalomon89/go-basics/internal/adapters/client"
// 	"github.com/osalomon89/go-basics/internal/adapters/handler"
// 	mysqlrepo "github.com/osalomon89/go-basics/internal/adapters/repository/mysql"
// 	"github.com/osalomon89/go-basics/internal/core/service"
// )

// func main() {
// 	if err := run(); err != nil {
// 		log.Fatal(err)
// 	}
// }

// func run() error {
// 	var wait time.Duration
// 	flag.DurationVar(&wait, "graceful-timeout", time.Second*15, "the duration for which the server gracefully wait for existing connections to finish - e.g. 15s or 1m")
// 	flag.Parse()

// 	// esCient, err := es8.NewDefaultClient()
// 	// if err != nil {
// 	// 	return err
// 	// }

// 	// repo := ds.NewEsRepository(esCient)
// 	// if err := repo.CreateIndex("items"); err != nil {
// 	// 	log.Fatalln(err)
// 	// }

// 	conn, err := mysqlrepo.GetConnectionDB()
// 	if err != nil {
// 		return err
// 	}

// 	repo := mysqlrepo.NewMySQLRepository(conn)

// 	providerClient := client.NewProviderClient()
// 	service := service.NewService(repo, providerClient) //itemServiceImpl

// 	h := handler.NewHandler(service) //ItemService

// 	r := mux.NewRouter()

// 	router := r.PathPrefix("/api-items/v1").Subrouter()

// 	router.HandleFunc("/hello", h.HelloHandler).Methods(http.MethodGet)

// 	router.HandleFunc("/items", h.GetAllItems).Methods(http.MethodGet)
// 	router.HandleFunc("/items", h.CreateItem).Methods(http.MethodPost)
// 	router.HandleFunc("/items/{id}", h.GetItemByID).Methods(http.MethodGet)
// 	router.HandleFunc("/items/{id}", h.UpdateItem).Methods(http.MethodPut)

// 	srv := &http.Server{
// 		Addr: "0.0.0.0:8080",
// 		// Good practice to set timeouts to avoid Slowloris attacks.
// 		WriteTimeout: time.Second * 15,
// 		ReadTimeout:  time.Second * 15,
// 		IdleTimeout:  time.Second * 60,
// 		Handler:      r, // Pass our instance of gorilla/mux in.
// 	}

// 	// Run our server in a goroutine so that it doesn't block.
// 	go func() {
// 		if err := srv.ListenAndServe(); err != nil {
// 			log.Println(err)
// 		}
// 	}()

// 	c := make(chan os.Signal, 1)
// 	// We'll accept graceful shutdowns when quit via SIGINT (Ctrl+C)
// 	// SIGKILL, SIGQUIT or SIGTERM (Ctrl+/) will not be caught.
// 	signal.Notify(c, os.Interrupt)

// 	// Block until we receive our signal.
// 	<-c

// 	// Create a deadline to wait for.
// 	ctx, cancel := context.WithTimeout(context.Background(), wait)
// 	defer cancel()
// 	// Doesn't block if no connections, but will otherwise wait
// 	// until the timeout deadline.
// 	srv.Shutdown(ctx)
// 	// Optionally, you could run srv.Shutdown in a goroutine and block on
// 	// <-ctx.Done() if your application should wait for other services
// 	// to finalize based on context cancellation.
// 	log.Println("shutting down")
// 	os.Exit(0)

// 	return nil
// }
