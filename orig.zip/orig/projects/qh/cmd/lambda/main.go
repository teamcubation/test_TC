package main

//"github.com/aws/aws-lambda-go/lambda"

//envs "github.com/devpablocristo/monorepo/pkg/config/godotenv"

func main() {

	// if err := envs.LoadConfig("config/.env", "config/.env.local"); err != nil {
	// 	log.Fatalf("Error loading config: %s", err)
	// }

	// customerRepository, err := custout.NewRepository()
	// if err != nil {
	// 	log.Fatalf("SQLite error: %v", err)
	// }

	// customerUsecases := custcore.NewUseCases(customerRepository)

	// lambdaHandler, err := custin.NewLambdaHandler(customerUsecases)
	// if err != nil {
	// 	panic(err)
	// }

	// lambda.Start(lambdaHandler.HandleRequest)
}
