package pkgmwr

import (
	"log"
	"net/http"

	"github.com/gin-gonic/gin"

	pkgtypes "github.com/devpablocristo/monorepo/pkg/types"
)

// ErrorHandlingMiddleware captura errores añadidos al contexto y responde de manera adecuada
func ErrorHandlingMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		log.Println("Error Handling Middleware: Starting...")
		c.Next() // Procesa la solicitud

		if len(c.Errors) > 0 {
			for _, ginErr := range c.Errors {
				// Loguear el error (opcional para monitoreo)
				log.Printf("Error: %v", ginErr.Err)

				// Manejar errores del dominio
				if apiErr, ok := ginErr.Err.(*pkgtypes.Error); ok {
					response := apiErr.ToJson() // Convertir a formato JSON
					status := mapErrorTypeToStatus(apiErr.Type)
					c.JSON(status, response)
				} else {
					// Manejar errores desconocidos como internos
					c.JSON(http.StatusInternalServerError, gin.H{
						"error":   "INTERNAL_ERROR",
						"message": ginErr.Err.Error(),
					})
				}
				return
			}
		}
	}
}

// Mapear tipos de errores a códigos HTTP
func mapErrorTypeToStatus(errType pkgtypes.ErrorType) int {
	switch errType {
	case pkgtypes.ErrNotFound:
		return http.StatusNotFound
	case pkgtypes.ErrValidation:
		return http.StatusBadRequest
	case pkgtypes.ErrConflict:
		return http.StatusConflict
	case pkgtypes.ErrAuthentication, pkgtypes.ErrAuthorization:
		return http.StatusUnauthorized
	case pkgtypes.ErrUnavailable:
		return http.StatusServiceUnavailable
	default:
		return http.StatusInternalServerError
	}
}
