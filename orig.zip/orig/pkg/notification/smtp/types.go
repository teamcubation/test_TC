package pkgsmtp

type Email struct {
	Address string
	Name    string
	Subject string
	Body    string
	Token   string
}
