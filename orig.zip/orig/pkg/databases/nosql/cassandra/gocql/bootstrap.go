package pkgcassandra

import (
	"github.com/spf13/viper"
)

func Bootstrap() (Repository, error) {
	config := newConfig(
		viper.GetStringSlice("CASSANDRA_HOSTS"),
		viper.GetString("CASSANDRA_KEYSPACE"),
		viper.GetString("CASSANDRA_USERNAME"),
		viper.GetString("CASSANDRA_PASSWORD"),
	)

	if err := config.Validate(); err != nil {
		return nil, err
	}

	return newRepository(config)
}
