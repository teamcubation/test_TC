package pkgmapdb

func Boostrap() Repository {
	return newRepository()
}
