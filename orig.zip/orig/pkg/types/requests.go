package pkgtypes

type LoginCredentials struct {
	Username string `json:"username,omitempty" binding:"omitempty"`    // Opcional
	Email    string `json:"email,omitempty" binding:"omitempty,email"` // Opcional, pero si está presente, debe ser un email válido
	Password string `json:"password" binding:"required"`               // Requerido siempre
}
